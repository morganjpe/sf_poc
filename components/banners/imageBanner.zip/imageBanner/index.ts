import ImageBanner from './ImageBanner';

export default ImageBanner;
